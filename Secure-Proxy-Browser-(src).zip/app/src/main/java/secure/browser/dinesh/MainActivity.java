package secure.browser.dinesh;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import info.guardianproject.netcipher.webkit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.webkit.HttpAuthHandler;

public class MainActivity extends Activity {
	
	private String host = "";
	private String ip = "";
	
	private View view1;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private FrameLayout frame_layout6;
	private WebView webview;
	private LinearLayout linear3;
	private TextView proxyStatus;
	private TextView textview1;
	private TextView textview2;
	private EditText urlInput;
	private Button goBtn;
	private Button backBtn;
	private Button forwardBtn;
	private Button refreshBtn;
	private Button stopBtn;
	private ProgressBar progressBar;
	
	// Proxy variables
	private String proxyIp = "";
	private String proxyPort = "";
	private String proxyUser = "";
	private String proxyPass = "";
	private ExecutorService executor = Executors.newSingleThreadExecutor();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
		fetchProxyCredentials(); // Fetch proxy from server
	}
	
	private void initialize(Bundle _savedInstanceState) {
		view1 = findViewById(R.id.view1);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		frame_layout6 = findViewById(R.id.frame_layout6);
		webview = findViewById(R.id.webview);
		
		// WebView settings
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setDomStorageEnabled(true);
		webview.getSettings().setLoadWithOverviewMode(true);
		webview.getSettings().setUseWideViewPort(true);
		webview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
		
		linear3 = findViewById(R.id.linear3);
		proxyStatus = findViewById(R.id.proxyStatus);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		urlInput = findViewById(R.id.urlInput);
		goBtn = findViewById(R.id.goBtn);
		backBtn = findViewById(R.id.backBtn);
		forwardBtn = findViewById(R.id.forwardBtn);
		refreshBtn = findViewById(R.id.refreshBtn);
		stopBtn = findViewById(R.id.stopBtn);
		progressBar = findViewById(R.id.progressBar);
		
		// WebView client with progress tracking
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				progressBar.setVisibility(View.VISIBLE);
				urlInput.setText(_url);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				progressBar.setVisibility(View.GONE);
				updateButtons();
				super.onPageFinished(_param1, _param2);
			}
		});
		
		// Go button click
		goBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String url = urlInput.getText().toString();
				if (!url.startsWith("http")) {
					url = "https://" + url;
				}
				webview.loadUrl(url);
			}
		});
		
		// Back button
		backBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (webview.canGoBack()) {
					webview.goBack();
				}
			}
		});
		
		// Forward button
		forwardBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (webview.canGoForward()) {
					webview.goForward();
				}
			}
		});
		
		// Refresh button
		refreshBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview.reload();
			}
		});
		
		// Stop button
		stopBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview.stopLoading();
			}
		});
	}
	
	private void initializeLogic() {
		proxyStatus.setText("Fetching proxy...");
	}
	
	// Fetch proxy from server
	private void fetchProxyCredentials() {
		executor.execute(new Runnable() {
			@Override
			public void run() {
				try {
				//replace the url with ur real url
					URL url = new URL("https://example.com/proxy.php");
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setConnectTimeout(15000);
					conn.setReadTimeout(15000);
					
					BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					StringBuilder sb = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null) {
						sb.append(line);
					}
					reader.close();
					conn.disconnect();
					
					JSONObject obj = new JSONObject(sb.toString());
					proxyIp = obj.getString("proxy1_ip");
					proxyPort = obj.getString("proxy1_port");
					proxyUser = obj.getString("proxy1_user");
					proxyPass = obj.getString("proxy1_pass");
					
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							proxyStatus.setText("Proxy: " + proxyIp);
							applyProxy(); // Apply proxy after fetching
						}
					});
				} catch (final Exception e) {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							proxyStatus.setText("Proxy: Failed to fetch");
							showMessage("Proxy fetch failed: " + e.getMessage());
						}
					});
					e.printStackTrace();
				}
			}
		});
	}
	
	// Apply proxy to WebView
	private void applyProxy() {
		if (proxyIp.isEmpty() || proxyPort.isEmpty()) {
			return;
		}
		
		try {
			// Set proxy using NetCipher
			WebkitProxy.setProxy(getPackageName(), getApplicationContext(), webview, proxyIp, Integer.parseInt(proxyPort));
			
			// Handle proxy authentication
			webview.setWebViewClient(new WebViewClient() {
				@Override
				public void onPageStarted(WebView view, String url, Bitmap favicon) {
					progressBar.setVisibility(View.VISIBLE);
					urlInput.setText(url);
					super.onPageStarted(view, url, favicon);
				}
				
				@Override
				public void onPageFinished(WebView view, String url) {
					progressBar.setVisibility(View.GONE);
					updateButtons();
					super.onPageFinished(view, url);
				}
				
				@Override
				public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
					if (proxyUser != null && !proxyUser.isEmpty()) {
						handler.proceed(proxyUser, proxyPass);
					} else {
						handler.cancel();
					}
				}
			});
			
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					proxyStatus.setText("Proxy: Active ✓");
					showMessage("Proxy connected successfully");
				}
			});
			
		} catch (Exception e) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					proxyStatus.setText("Proxy: Failed");
					showMessage("Proxy error: " + e.getMessage());
				}
			});
			e.printStackTrace();
		}
	}
	
	private void updateButtons() {
		backBtn.setEnabled(webview.canGoBack());
		forwardBtn.setEnabled(webview.canGoForward());
	}
	
	@Override
	public void onBackPressed() {
		if (webview.canGoBack()) {
			webview.goBack();
		} else {
			super.onBackPressed();
		}
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (executor != null) {
			executor.shutdownNow();
		}
		if (webview != null) {
			webview.stopLoading();
			webview.destroy();
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}